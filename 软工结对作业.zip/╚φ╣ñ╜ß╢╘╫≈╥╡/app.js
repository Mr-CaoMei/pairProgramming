// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    //登录
   wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }

    })

   wx.request({  
      url: 'http://172.17.173.97:8080/api/user/login',  //接口
      method: 'post',  
      data: {  
        student_id:"031902104", //这里是发送给服务器的参数（参数名：参数值）  
        password:"12345678"
      },  
      header: {  
        'content-type': 'application/x-www-form-urlencoded'  //这里注意POST请求content-type是小写，大写会报错  
      },   
      
  });
  
  },
  globalData: {
    userInfo: null
  }
})

// pages/mc/mc.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    score_A:0,
    score_B:0,
    flag_A:1,//玩家开始标志
    flag_B:0,//人机开始标志
    flag:0,//记录从放置区清零开始的轮次
    A_num_mei:0,//玩家A手持梅花数
    A_num_fang:0,//玩家A手持方块数
    A_num_hong:0,//玩家A手持红桃数
    A_num_hei:0,//玩家A手持黑桃数
    B_num_mei:0,//玩家B手持梅花数
    B_num_fang:0,//玩家B手持方块数
    B_num_hong:0,//玩家B手持红桃数
    B_num_hei:0,//玩家B手持黑桃数
    unused_num:52,//牌组剩余数
    count:52,//下一张卡牌信息
    count_old:52,//当前卡牌信息
    count_old_old:52,//上一次卡牌信息
    pokerexit:[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
               0,0,0,0,0,0,0,0,0,0,0,0],//已抽过卡牌的标记数组
    pokercard:[//存储卡牌种类
    'Amei', '2mei','3mei','4mei','5mei','6mei','7mei','8mei','9mei','10mei','Jmei','Qmei','Kmei', 
    'Afang','2fang','3fang','4fang','5fang','6fang','7fang','8fang','9fang','10fang','Jfang','Qfang','Kfang',
    'Ahong','2hong','3hong','4hong','5hong','6hong','7hong','8hong','9hong','10hong','Jhong','Qhong','Khong',
    'Ahei','2hei','3hei','4hei','5hei','6hei','7hei','8hei','9hei','10hei','Jhei','Qhei','Khei','pokerFace'], 
    stack_container_mei:[],//放置区梅花卡牌暂存区 
    stack_num_mei:0,//梅花卡牌暂存区中卡牌数
    stack_container_fang:[],//放置区方块卡牌暂存区
    stack_num_fang:0,//方块卡牌暂存区中卡牌数
    stack_container_hong:[],//放置区红桃卡牌暂存区
    stack_num_hong:0,//红桃卡牌暂存区中卡牌数
    stack_container_hei:[],//放置区黑桃卡牌暂存区
    stack_num_hei:0,//黑桃卡牌暂存区中卡牌数
    stack_mei_A:[],//玩家A梅花卡牌
    stack_fang_A:[],//玩家A梅花卡牌
    stack_hong_A:[],//玩家A梅花卡牌
    stack_hei_A:[],//玩家A梅花卡牌
    stack_mei_B:[],//玩家B梅花卡牌
    stack_fang_B:[],//玩家B方块卡牌
    stack_hong_B:[],//玩家B红桃卡牌
    stack_hei_B:[],//玩家B黑桃卡牌
  },

  randon_num(){
    var tmp=0
    tmp= Math.floor(Math.random()*52)
    //console.log(tmp)
   while(this.data.pokerexit[tmp]==1){
       tmp=Math.floor(Math.random()*52)
     }   
   this.setData({
     count:tmp
   }) 
   //console.log(tmp) 
  }, 
  back_main(){//索引返回主页面
    wx.navigateTo({
      url: '/pages/homePage/homePage',
    })
  },
  click_Amei(){
    if(this.data.flag_A==1){
      if(this.data.A_num_mei>0){
        this.setData({
          A_num_mei:this.data.A_num_mei-1//梅花卡组卡牌数-1
        }) 
        this.setData({
          flag_A:0,
          flag_B:1 ,//设置使能轮换为玩家B
          flag:this.data.flag+1
        })
        this.setData({
          count_old:this.data.count,//记录上一张卡牌
          count:this.data.stack_mei_A.pop(),//弹出玩家梅花卡牌最顶部一张并记录
          stack_container_mei:this.data.stack_container_mei.concat(this.data.count),
          //将卡牌加入到放置区梅花卡组
          stack_num_mei:this.data.stack_num_mei+1
          //放置区梅花卡组数+1
        })

        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=0&&this.data.count_old<=12){//满足猪尾巴
            this.setData({
              stack_mei_A:this.data.stack_mei_A.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家A梅花卡组
              A_num_mei:this.data.A_num_mei+this.data.stack_num_mei,
              //将玩家A梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_A:this.data.stack_fang_A.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家A方块卡组
              A_num_fang:this.data.A_num_fang+this.data.stack_num_fang,
              //将玩家A方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_A:this.data.stack_hong_A.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家A红桃卡组
              A_num_hong:this.data.A_num_hong+this.data.stack_num_hong,
              //将玩家A红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_A:this.data.stack_hei_A.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家A黑桃卡组
              A_num_hei:this.data.A_num_hei+this.data.stack_num_hei,
              //将玩家A黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
      }
    }
  },
  click_Afang(){
    if(this.data.flag_A==1){
      if(this.data.A_num_fang>0){
        this.setData({
          A_num_fang:this.data.A_num_fang-1//玩家A方块卡组卡牌数-1
        })
        this.setData({
          flag_A:0,
          flag_B:1,//玩家轮次是能轮换
          flag:this.data.flag+1
        })
        this.setData({
          count_old:this.data.count,//记录上一张卡牌
          count:this.data.stack_fang_A.pop(),//从玩家方块卡牌弹出顶部一张
          stack_container_fang:this.data.stack_container_fang.concat(this.data.count),
          //将卡牌加入到对应花色放置区数组
          stack_num_fang:this.data.stack_num_fang+1
          //对应卡牌放置区卡牌数+1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=13&&this.data.count_old<=25){//满足猪尾巴
            this.setData({
              stack_mei_A:this.data.stack_mei_A.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家A梅花卡组
              A_num_mei:this.data.A_num_mei+this.data.stack_num_mei,
              //将玩家A梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_A:this.data.stack_fang_A.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家A方块卡组
              A_num_fang:this.data.A_num_fang+this.data.stack_num_fang,
              //将玩家A方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_A:this.data.stack_hong_A.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家A红桃卡组
              A_num_hong:this.data.A_num_hong+this.data.stack_num_hong,
              //将玩家A红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_A:this.data.stack_hei_A.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家A黑桃卡组
              A_num_hei:this.data.A_num_hei+this.data.stack_num_hei,
              //将玩家A黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
      }
    }
    
  },
  click_Ahong(){
    if(this.data.flag_A==1){
      if(this.data.A_num_hong>0){
        this.setData({
          A_num_hong:this.data.A_num_hong-1//玩家A红桃卡牌数-1
        })
        this.setData({
          flag_A:0,
          flag_B:1,//使能轮换
          flag:this.data.flag+1
        })
        this.setData({
          count_old:this.data.count,//记录上张卡牌
          count:this.data.stack_hong_A.pop(),//弹出对应花色卡牌
          stack_container_hong:this.data.stack_container_hong.concat(this.data.count),
          //将对应卡牌加入对应花色放置区
          stack_num_hong:this.data.stack_num_hong+1
          //对应花色放置区卡牌数+1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=26&&this.data.count_old<=38){//满足猪尾巴
            this.setData({
              stack_mei_A:this.data.stack_mei_A.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家A梅花卡组
              A_num_mei:this.data.A_num_mei+this.data.stack_num_mei,
              //将玩家A梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_A:this.data.stack_fang_A.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家A方块卡组
              A_num_fang:this.data.A_num_fang+this.data.stack_num_fang,
              //将玩家A方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_A:this.data.stack_hong_A.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家A红桃卡组
              A_num_hong:this.data.A_num_hong+this.data.stack_num_hong,
              //将玩家A红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_A:this.data.stack_hei_A.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家A黑桃卡组
              A_num_hei:this.data.A_num_hei+this.data.stack_num_hei,
              //将玩家A黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
      }
    }
    
  },
  click_Ahei(){
    if(this.data.flag_A==1){
    if(this.data.A_num_hei>0){
      this.setData({ 
        A_num_hei:this.data.A_num_hei-1//玩家A黑桃卡牌数-1
      })
      this.setData({
        flag_A:0,
        flag_B:1,
        flag:this.data.flag+1
      })
      this.setData({
        count_old:this.data.count,//记录上一张卡牌
        count:this.data.stack_hei_A.pop(),//从玩家A黑桃卡牌弹出顶部卡牌
        stack_container_hei:this.data.stack_container_hei.concat(this.data.count),
        //将弹出卡牌加入至放置区对应花色卡牌
        stack_num_hei:this.data.stack_num_hei+1
        //对应花色放置区卡牌数+1
      })
      if(this.data.flag>=2){
        //console.log(this.data.count_old)
        if(this.data.count_old>=39&&this.data.count_old<=51){//满足猪尾巴
          this.setData({
            stack_mei_A:this.data.stack_mei_A.concat(this.data.stack_container_mei),
            //将梅花牌从暂存器放入玩家A梅花卡组
            A_num_mei:this.data.A_num_mei+this.data.stack_num_mei,
            //将玩家A梅花卡牌数重新统计
            stack_num_mei:0,//将梅花暂存区卡牌数置0

            stack_fang_A:this.data.stack_fang_A.concat(this.data.stack_container_fang),
            //将方块牌从暂存器放入玩家A方块卡组
            A_num_fang:this.data.A_num_fang+this.data.stack_num_fang,
            //将玩家A方块卡牌数重新统计
            stack_num_fang:0,//将方块暂存区卡牌数置0

            stack_hong_A:this.data.stack_hong_A.concat(this.data.stack_container_hong),
            //将红桃牌从暂存器放入玩家A红桃卡组
            A_num_hong:this.data.A_num_hong+this.data.stack_num_hong,
            //将玩家A红桃卡牌数重新统计
            stack_num_hong:0,//将红桃暂存区卡牌数置0

            stack_hei_A:this.data.stack_hei_A.concat(this.data.stack_container_hei),
            //将黑桃牌从暂存器放入玩家A黑桃卡组
            A_num_hei:this.data.A_num_hei+this.data.stack_num_hei,
            //将玩家A黑桃卡牌数重新统计
            stack_num_hei:0,//将黑桃暂存区卡牌数置0
            flag:0,
            count:52,
            count_old:52
          })
        }
      }
    }
  }
  },
  click_Bmei(){
    if(this.data.flag_B==1){
    if(this.data.B_num_mei>0){
      this.setData({
        B_num_mei:this.data.B_num_mei-1
      }) 
      this.setData({
        flag_B:0,
        flag_A:1,
        flag:this.data.flag+1
      })
      this.setData({
        count_old:this.data.count,
        count:this.data.stack_mei_B.pop(),
        stack_container_mei:this.data.stack_container_mei.concat(this.data.count),
        stack_num_mei:this.data.stack_num_mei+1
      })
      if(this.data.flag>=2){
        //console.log(this.data.count_old)
        if(this.data.count_old>=0&&this.data.count_old<=12){//满足猪尾巴
          this.setData({
            stack_mei_B:this.data.stack_mei_B.concat(this.data.stack_container_mei),
            //将梅花牌从暂存器放入玩家B梅花卡组
            B_num_mei:this.data.B_num_mei+this.data.stack_num_mei,
            //将玩家B梅花卡牌数重新统计
            stack_num_mei:0,//将梅花暂存区卡牌数置0

            stack_fang_B:this.data.stack_fang_B.concat(this.data.stack_container_fang),
            //将方块牌从暂存器放入玩家B方块卡组
            B_num_fang:this.data.B_num_fang+this.data.stack_num_fang,
            //将玩家B方块卡牌数重新统计
            stack_num_fang:0,//将方块暂存区卡牌数置0

            stack_hong_B:this.data.stack_hong_B.concat(this.data.stack_container_hong),
            //将红桃牌从暂存器放入玩家B红桃卡组
            B_num_hong:this.data.B_num_hong+this.data.stack_num_hong,
            //将玩家B红桃卡牌数重新统计
            stack_num_hong:0,//将红桃暂存区卡牌数置0

            stack_hei_B:this.data.stack_hei_B.concat(this.data.stack_container_hei),
            //将黑桃牌从暂存器放入玩家B黑桃卡组
            B_num_hei:this.data.B_num_hei+this.data.stack_num_hei,
            //将玩家B黑桃卡牌数重新统计
            stack_num_hei:0,//将黑桃暂存区卡牌数置0
            flag:0,
            count:52,
            count_old:52
          })
        }
      } 
    }
  }
  },
  click_Bfang(){
    if(this.data.flag_B==1){
    if(this.data.B_num_fang>0){
      this.setData({
        B_num_fang:this.data.B_num_fang-1
      })
      this.setData({
        flag_B:0,
        flag_A:1,
        flag:this.data.flag+1
      })
      this.setData({
        count_old:this.data.count,
        count:this.data.stack_fang_B.pop(),
        stack_container_fang:this.data.stack_container_fang.concat(this.data.count),
        stack_num_fang:this.data.stack_num_fang+1
      })
      if(this.data.flag>=2){
        //console.log(this.data.count_old)
        if(this.data.count_old>=13&&this.data.count_old<=25){//满足猪尾巴
          this.setData({
            stack_mei_B:this.data.stack_mei_B.concat(this.data.stack_container_mei),
            //将梅花牌从暂存器放入玩家B梅花卡组
            B_num_mei:this.data.B_num_mei+this.data.stack_num_mei,
            //将玩家B梅花卡牌数重新统计
            stack_num_mei:0,//将梅花暂存区卡牌数置0

            stack_fang_B:this.data.stack_fang_B.concat(this.data.stack_container_fang),
            //将方块牌从暂存器放入玩家B方块卡组
            B_num_fang:this.data.B_num_fang+this.data.stack_num_fang,
            //将玩家B方块卡牌数重新统计
            stack_num_fang:0,//将方块暂存区卡牌数置0

            stack_hong_B:this.data.stack_hong_B.concat(this.data.stack_container_hong),
            //将红桃牌从暂存器放入玩家B红桃卡组
            B_num_hong:this.data.B_num_hong+this.data.stack_num_hong,
            //将玩家B红桃卡牌数重新统计
            stack_num_hong:0,//将红桃暂存区卡牌数置0

            stack_hei_B:this.data.stack_hei_B.concat(this.data.stack_container_hei),
            //将黑桃牌从暂存器放入玩家B黑桃卡组
            B_num_hei:this.data.B_num_hei+this.data.stack_num_hei,
            //将玩家B黑桃卡牌数重新统计
            stack_num_hei:0,//将黑桃暂存区卡牌数置0
            flag:0,
            count:52,
            count_old:52
          })
        }
      }
    }
  }
  },
  click_Bhong(){
    if(this.data.flag_B==1){
    if(this.data.B_num_hong>0){
      this.setData({
        B_num_hong:this.data.B_num_hong-1
      }) 
      this.setData({
        flag_B:0,
        flag_A:1,
        flag:this.data.flag+1
      })
      this.setData({
        count_old:this.data.count,
        count:this.data.stack_hong_B.pop(),
        stack_container_hong:this.data.stack_container_hong.concat(this.data.count),
        stack_num_hong:this.data.stack_num_hong+1
      })
      if(this.data.flag>=2){
        //console.log(this.data.count_old)
        if(this.data.count_old>=26&&this.data.count_old<=38){//满足猪尾巴
          this.setData({
            stack_mei_B:this.data.stack_mei_B.concat(this.data.stack_container_mei),
            //将梅花牌从暂存器放入玩家B梅花卡组
            B_num_mei:this.data.B_num_mei+this.data.stack_num_mei,
            //将玩家B梅花卡牌数重新统计
            stack_num_mei:0,//将梅花暂存区卡牌数置0

            stack_fang_B:this.data.stack_fang_B.concat(this.data.stack_container_fang),
            //将方块牌从暂存器放入玩家B方块卡组
            B_num_fang:this.data.B_num_fang+this.data.stack_num_fang,
            //将玩家B方块卡牌数重新统计
            stack_num_fang:0,//将方块暂存区卡牌数置0

            stack_hong_B:this.data.stack_hong_B.concat(this.data.stack_container_hong),
            //将红桃牌从暂存器放入玩家B红桃卡组
            B_num_hong:this.data.B_num_hong+this.data.stack_num_hong,
            //将玩家B红桃卡牌数重新统计
            stack_num_hong:0,//将红桃暂存区卡牌数置0

            stack_hei_B:this.data.stack_hei_B.concat(this.data.stack_container_hei),
            //将黑桃牌从暂存器放入玩家B黑桃卡组
            B_num_hei:this.data.B_num_hei+this.data.stack_num_hei,
            //将玩家B黑桃卡牌数重新统计
            stack_num_hei:0,//将黑桃暂存区卡牌数置0
            flag:0,
            count:52,
            count_old:52
          })
        }
      }
    } 
  }
  },  
  click_Bhei(){
    if(this.data.flag_B==1){
    if(this.data.B_num_hei>0){
      this.setData({
        B_num_hei:this.data.B_num_hei-1
      })
      this.setData({
        flag_B:0,
        flag_A:1,
        flag:this.data.flag+1
      })
      this.setData({
        count_old:this.data.count,
        count:this.data.stack_hei_B.pop(),
        stack_container_hei:this.data.stack_container_hei.concat(this.data.count),
        stack_num_hei:this.data.stack_num_hei+1
      })
      if(this.data.flag>=2){
        //console.log(this.data.count_old)
        if(this.data.count_old>=39&&this.data.count_old<=51){//满足猪尾巴
          this.setData({
            stack_mei_B:this.data.stack_mei_B.concat(this.data.stack_container_mei),
            //将梅花牌从暂存器放入玩家B梅花卡组
            B_num_mei:this.data.B_num_mei+this.data.stack_num_mei,
            //将玩家B梅花卡牌数重新统计
            stack_num_mei:0,//将梅花暂存区卡牌数置0

            stack_fang_B:this.data.stack_fang_B.concat(this.data.stack_container_fang),
            //将方块牌从暂存器放入玩家B方块卡组
            B_num_fang:this.data.B_num_fang+this.data.stack_num_fang,
            //将玩家B方块卡牌数重新统计
            stack_num_fang:0,//将方块暂存区卡牌数置0

            stack_hong_B:this.data.stack_hong_B.concat(this.data.stack_container_hong),
            //将红桃牌从暂存器放入玩家B红桃卡组
            B_num_hong:this.data.B_num_hong+this.data.stack_num_hong,
            //将玩家B红桃卡牌数重新统计
            stack_num_hong:0,//将红桃暂存区卡牌数置0

            stack_hei_B:this.data.stack_hei_B.concat(this.data.stack_container_hei),
            //将黑桃牌从暂存器放入玩家B黑桃卡组
            B_num_hei:this.data.B_num_hei+this.data.stack_num_hei,
            //将玩家B黑桃卡牌数重新统计
            stack_num_hei:0,//将黑桃暂存区卡牌数置0
            flag:0,
            count:52,
            count_old:52
          })
        }
      }
    }
  }
  },
  showok:function() {
		wx.showToast({
		  	title: '成功',
		  	icon: 'success',
		  	duration: 2000
		})
	},

  click_unused_randon_num(){//点击牌组发牌
     if(this.data.count>=0){
       this.setData({
        unused_num:this.data.unused_num-1,
       })
     } 
    this.setData({//卡组牌数-1,并存储上一张卡牌
      count_old:this.data.count,//拷贝当前卡牌
    })  
    var tmp=0 
    tmp= Math.round(Math.random()*50)
   while(this.data.pokerexit[tmp]==1){
       tmp=Math.round(Math.random()*50);
       if(this.data.unused_num==0){
         this.setData({
           score_A:
           this.data.A_num_mei+this.data.A_num_fang+this.data.A_num_hong+this.data.A_num_hei,
           score_B:
           this.data.B_num_mei+this.data.B_num_fang+this.data.B_num_hong+this.data.B_num_hei,
         })
         if(this.data.score_A>this.data.score_B){
          wx.showToast({
            title: '蝙蝠侠获胜',
            icon: 'success',
            duration: 2000
        })
        wx.clearStorage()
         }
         else if(this.data.score_A<this.data.score_B){
          wx.showToast({
            title: '超人获胜',
            icon: 'success',
            duration: 2000
        })
        wx.clearStorage()
         }
         else{
          if(this.data.score_A==this.data.score_B){
            wx.showToast({
              title: '蝙蝠侠和超人打平手',
              icon: 'success',
              duration: 2000
          }) 
          wx.clearStorage()
           }
         }
         wx.redirectTo({
          url: '/pages/homePage/homePage'
        })
       }
     }   
   this.setData({ 
     count:tmp,
     flag:this.data.flag+1
   }) 
   this.data.pokerexit[this.data.count]=1
   console.log(this.data.pokerexit,this.data.count) 
   if(this.data.count>=0&&this.data.count<52){//如果卡牌为有效卡牌0~51
     if(this.data.count>=0&&this.data.count<=12){//如果卡牌为梅花
      this.setData({
        stack_container_mei:this.data.stack_container_mei.concat(this.data.count)
      })
      //将梅花卡牌存入梅花暂存器
      this.setData({
        stack_num_mei:this.data.stack_num_mei+1//将梅花暂存器卡牌数+1
      }) 
       if(this.data.flag_A==1){//如果此时为玩家A的轮次
        this.setData({
          flag_A:0,
          flag_B:1
        })
        //console.log(this.data.flag_B)
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=0&&this.data.count_old<=12){//满足猪尾巴
            this.setData({
              stack_mei_A:this.data.stack_mei_A.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家A梅花卡组
              A_num_mei:this.data.A_num_mei+this.data.stack_num_mei,
              //将玩家A梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_A:this.data.stack_fang_A.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家A方块卡组
              A_num_fang:this.data.A_num_fang+this.data.stack_num_fang,
              //将玩家A方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_A:this.data.stack_hong_A.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家A红桃卡组
              A_num_hong:this.data.A_num_hong+this.data.stack_num_hong,
              //将玩家A红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_A:this.data.stack_hei_A.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家A黑桃卡组
              A_num_hei:this.data.A_num_hei+this.data.stack_num_hei,
              //将玩家A黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
       } 

       else if(this.data.flag_B==1){//如果此时为玩家B的轮次
        this.setData({
          flag_B:0,
          flag_A:1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=0&&this.data.count_old<=12){//满足猪尾巴
            this.setData({
              stack_mei_B:this.data.stack_mei_B.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家B梅花卡组
              B_num_mei:this.data.B_num_mei+this.data.stack_num_mei,
              //将玩家B梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_B:this.data.stack_fang_B.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家B方块卡组
              B_num_fang:this.data.B_num_fang+this.data.stack_num_fang,
              //将玩家B方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_B:this.data.stack_hong_B.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家B红桃卡组
              B_num_hong:this.data.B_num_hong+this.data.stack_num_hong,
              //将玩家B红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_B:this.data.stack_hei_B.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家B黑桃卡组
              B_num_hei:this.data.B_num_hei+this.data.stack_num_hei,
              //将玩家B黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        } 
       }
     }

     else if(this.data.count>=13&&this.data.count<=25){//如果卡牌为方块
      this.setData({
        stack_container_fang:this.data.stack_container_fang.concat(this.data.count)
      })
      //将方块卡牌存入方块暂存器
      this.setData({
        stack_num_fang:this.data.stack_num_fang+1//将方块暂存器卡牌数+1
      })
       if(this.data.flag_A==1){//如果此时为玩家A的轮次
        this.setData({
          flag_A:0,
          flag_B:1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=13&&this.data.count_old<=25){//满足猪尾巴
            this.setData({
              stack_mei_A:this.data.stack_mei_A.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家A梅花卡组
              A_num_mei:this.data.A_num_mei+this.data.stack_num_mei,
              //将玩家A梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_A:this.data.stack_fang_A.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家A方块卡组
              A_num_fang:this.data.A_num_fang+this.data.stack_num_fang,
              //将玩家A方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_A:this.data.stack_hong_A.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家A红桃卡组
              A_num_hong:this.data.A_num_hong+this.data.stack_num_hong,
              //将玩家A红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_A:this.data.stack_hei_A.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家A黑桃卡组
              A_num_hei:this.data.A_num_hei+this.data.stack_num_hei,
              //将玩家A黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
       }

       else if(this.data.flag_B==1){//如果此时为玩家B的轮次
        this.setData({
          flag_B:0,
          flag_A:1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=13&&this.data.count_old<=25){//满足猪尾巴
            this.setData({
              stack_mei_B:this.data.stack_mei_B.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家B梅花卡组
              B_num_mei:this.data.B_num_mei+this.data.stack_num_mei,
              //将玩家B梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_B:this.data.stack_fang_B.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家B方块卡组
              B_num_fang:this.data.B_num_fang+this.data.stack_num_fang,
              //将玩家B方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_B:this.data.stack_hong_B.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家B红桃卡组
              B_num_hong:this.data.B_num_hong+this.data.stack_num_hong,
              //将玩家B红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_B:this.data.stack_hei_B.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家B黑桃卡组
              B_num_hei:this.data.B_num_hei+this.data.stack_num_hei,
              //将玩家B黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
       }
     }

     else if(this.data.count>=26&&this.data.count<=38){//如果卡牌为红桃
      this.setData({
        stack_container_hong:this.data.stack_container_hong.concat(this.data.count)
      })
      //将红桃卡牌存入红桃暂存器
      this.setData({
        stack_num_hong:this.data.stack_num_hong+1//将红桃暂存器卡牌数+1
      })
       if(this.data.flag_A==1){//如果此时为玩家A的轮次
        this.setData({
          flag_A:0,
          flag_B:1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=26&&this.data.count_old<=38){//满足猪尾巴
            this.setData({
              stack_mei_A:this.data.stack_mei_A.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家A梅花卡组
              A_num_mei:this.data.A_num_mei+this.data.stack_num_mei,
              //将玩家A梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_A:this.data.stack_fang_A.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家A方块卡组
              A_num_fang:this.data.A_num_fang+this.data.stack_num_fang,
              //将玩家A方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_A:this.data.stack_hong_A.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家A红桃卡组
              A_num_hong:this.data.A_num_hong+this.data.stack_num_hong,
              //将玩家A红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_A:this.data.stack_hei_A.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家A黑桃卡组
              A_num_hei:this.data.A_num_hei+this.data.stack_num_hei,
              //将玩家A黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
       }

       else if(this.data.flag_B==1){//如果此时为玩家B的轮次
        this.setData({
          flag_B:0,
          flag_A:1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=26&&this.data.count_old<=38){//满足猪尾巴
            this.setData({
              stack_mei_B:this.data.stack_mei_B.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家B梅花卡组
              B_num_mei:this.data.B_num_mei+this.data.stack_num_mei,
              //将玩家B梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_B:this.data.stack_fang_B.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家B方块卡组
              B_num_fang:this.data.B_num_fang+this.data.stack_num_fang,
              //将玩家B方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_B:this.data.stack_hong_B.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家B红桃卡组
              B_num_hong:this.data.B_num_hong+this.data.stack_num_hong,
              //将玩家B红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_B:this.data.stack_hei_B.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家B黑桃卡组
              B_num_hei:this.data.B_num_hei+this.data.stack_num_hei,
              //将玩家B黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
       }
     }
  
     else if(this.data.count>=39&&this.data.count<=51){//如果卡牌为黑桃
      this.setData({
        stack_container_hei:this.data.stack_container_hei.concat(this.data.count)
      })
      //将黑桃卡牌存入红桃暂存器
      this.setData({
        stack_num_hei:this.data.stack_num_hei+1//将黑桃暂存器卡牌数+1
      })
       if(this.data.flag_A==1){//如果此时为玩家A的轮次
        this.setData({
          flag_A:0,
          flag_B:1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=39&&this.data.count_old<=51){//满足猪尾巴
            this.setData({
              stack_mei_A:this.data.stack_mei_A.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家A梅花卡组
              A_num_mei:this.data.A_num_mei+this.data.stack_num_mei,
              //将玩家A梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_A:this.data.stack_fang_A.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家A方块卡组
              A_num_fang:this.data.A_num_fang+this.data.stack_num_fang,
              //将玩家A方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_A:this.data.stack_hong_A.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家A红桃卡组
              A_num_hong:this.data.A_num_hong+this.data.stack_num_hong,
              //将玩家A红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_A:this.data.stack_hei_A.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家A黑桃卡组
              A_num_hei:this.data.A_num_hei+this.data.stack_num_hei,
              //将玩家A黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
       }

       else if(this.data.flag_B==1){//如果此时为玩家B的轮次
        this.setData({
          flag_B:0,
          flag_A:1
        })
        if(this.data.flag>=2){
          //console.log(this.data.count_old)
          if(this.data.count_old>=39&&this.data.count_old<=51){//满足猪尾巴
            this.setData({
              stack_mei_B:this.data.stack_mei_B.concat(this.data.stack_container_mei),
              //将梅花牌从暂存器放入玩家B梅花卡组
              B_num_mei:this.data.B_num_mei+this.data.stack_num_mei,
              //将玩家B梅花卡牌数重新统计
              stack_num_mei:0,//将梅花暂存区卡牌数置0

              stack_fang_B:this.data.stack_fang_B.concat(this.data.stack_container_fang),
              //将方块牌从暂存器放入玩家B方块卡组
              B_num_fang:this.data.B_num_fang+this.data.stack_num_fang,
              //将玩家B方块卡牌数重新统计
              stack_num_fang:0,//将方块暂存区卡牌数置0

              stack_hong_B:this.data.stack_hong_B.concat(this.data.stack_container_hong),
              //将红桃牌从暂存器放入玩家B红桃卡组
              B_num_hong:this.data.B_num_hong+this.data.stack_num_hong,
              //将玩家B红桃卡牌数重新统计
              stack_num_hong:0,//将红桃暂存区卡牌数置0

              stack_hei_B:this.data.stack_hei_B.concat(this.data.stack_container_hei),
              //将黑桃牌从暂存器放入玩家B黑桃卡组
              B_num_hei:this.data.B_num_hei+this.data.stack_num_hei,
              //将玩家B黑桃卡牌数重新统计
              stack_num_hei:0,//将黑桃暂存区卡牌数置0
              flag:0,
              count:52,
              count_old:52
            })
          }
        }
       }
     }
   } 
  },
  /**  
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})